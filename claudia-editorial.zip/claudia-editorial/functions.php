<?php
/**
 * Claudia Editorial — theme functions.
 *
 * @package Claudia_Editorial
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

if ( ! function_exists( 'claudia_editorial_setup' ) ) {
	/**
	 * Register theme support and navigation menus.
	 */
	function claudia_editorial_setup() {
		load_theme_textdomain( 'claudia-editorial', get_template_directory() . '/languages' );

		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
		add_theme_support( 'responsive-embeds' );
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 60,
				'width'       => 240,
				'flex-height' => true,
				'flex-width'  => true,
			)
		);

		register_nav_menus(
			array(
				'primary' => __( 'Hauptmenü', 'claudia-editorial' ),
				'footer'  => __( 'Footer-Menü', 'claudia-editorial' ),
			)
		);

		// Jetpack compatibility: responsive videos and content options.
		add_theme_support( 'jetpack-responsive-videos' );
		add_theme_support(
			'jetpack-content-options',
			array(
				'blog-display' => 'content',
				'post-details' => array(
					'stylesheet' => 'claudia-editorial-main',
					'date'       => '.meta time',
				),
			)
		);

		// Nicer excerpts.
		add_filter( 'excerpt_length', function () { return 26; } );
		add_filter( 'excerpt_more', function () { return '…'; } );
	}
}
add_action( 'after_setup_theme', 'claudia_editorial_setup' );

// E-mail subscription / newsletter feature.
require get_template_directory() . '/inc/newsletter.php';

/**
 * Enqueue styles, fonts and scripts.
 */
function claudia_editorial_assets() {
	// Google Fonts: Cormorant Garamond (serif) + Inter (sans).
	wp_enqueue_style(
		'claudia-editorial-fonts',
		'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600;1,500&family=Inter:wght@400;500;600&display=swap',
		array(),
		null
	);

	$dir = get_template_directory();
	$uri = get_template_directory_uri();

	// File modification times are used as version strings, so any edit to a
	// stylesheet/script automatically busts the browser and CDN cache.
	$css_ver  = file_exists( $dir . '/style.css' ) ? filemtime( $dir . '/style.css' ) : false;
	$main_ver = file_exists( $dir . '/assets/css/main.css' ) ? filemtime( $dir . '/assets/css/main.css' ) : false;
	$js_ver   = file_exists( $dir . '/assets/js/main.js' ) ? filemtime( $dir . '/assets/js/main.js' ) : false;

	// Required base stylesheet (theme header).
	wp_enqueue_style( 'claudia-editorial-base', get_stylesheet_uri(), array(), $css_ver );

	// Main shared stylesheet.
	wp_enqueue_style(
		'claudia-editorial-main',
		$uri . '/assets/css/main.css',
		array( 'claudia-editorial-base' ),
		$main_ver
	);

	wp_enqueue_script(
		'claudia-editorial-nav',
		$uri . '/assets/js/main.js',
		array(),
		$js_ver,
		true
	);

	// AJAX endpoint for the instant newsletter feedback.
	wp_localize_script(
		'claudia-editorial-nav',
		'ClaudiaNL',
		array( 'ajax' => admin_url( 'admin-ajax.php' ) )
	);

	// Free DE/EN translation switch (only when enabled and no plugin shortcode set).
	if ( claudia_gtranslate_active() ) {
		$tr_ver = file_exists( $dir . '/assets/js/translate.js' ) ? filemtime( $dir . '/assets/js/translate.js' ) : false;
		wp_enqueue_script( 'claudia-editorial-translate', $uri . '/assets/js/translate.js', array(), $tr_ver, true );
	}

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'claudia_editorial_assets' );

/**
 * Register a footer widget area.
 */
function claudia_editorial_widgets() {
	register_sidebar(
		array(
			'name'          => __( 'Footer', 'claudia-editorial' ),
			'id'            => 'footer-1',
			'description'   => __( 'Erscheint im Footer.', 'claudia-editorial' ),
			'before_widget' => '<div class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4>',
			'after_title'   => '</h4>',
		)
	);
}
add_action( 'widgets_init', 'claudia_editorial_widgets' );

/**
 * Customizer: a field to drop in a translation plugin's language-switcher
 * shortcode, shown in the header (e.g. [gtranslate], [weglot_switcher],
 * [language-switcher]).
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 */
function claudia_customize_register( $wp_customize ) {
	$wp_customize->add_section(
		'claudia_language',
		array(
			'title'    => __( 'Sprache / Übersetzung', 'claudia-editorial' ),
			'priority' => 160,
		)
	);
	$wp_customize->add_setting(
		'claudia_enable_gtranslate',
		array(
			'default'           => true,
			'sanitize_callback' => 'wp_validate_boolean',
		)
	);
	$wp_customize->add_control(
		'claudia_enable_gtranslate',
		array(
			'label'       => __( 'Kostenlose Google-Übersetzung (DE/EN) aktivieren', 'claudia-editorial' ),
			'description' => __( 'Zeigt oben rechts einen DE/EN-Umschalter. Google wird erst kontaktiert, wenn ein Besucher auf EN klickt.', 'claudia-editorial' ),
			'section'     => 'claudia_language',
			'type'        => 'checkbox',
		)
	);
	$wp_customize->add_setting(
		'claudia_lang_shortcode',
		array(
			'default'           => '',
			'sanitize_callback' => 'wp_kses_post',
		)
	);
	$wp_customize->add_control(
		'claudia_lang_shortcode',
		array(
			'label'       => __( 'Oder: Sprachumschalter-Shortcode', 'claudia-editorial' ),
			'description' => __( 'Nutzt du lieber ein Übersetzungs-Plugin, trage hier dessen Shortcode ein (z. B. [gtranslate], [weglot_switcher]). Hat Vorrang vor der Google-Übersetzung oben.', 'claudia-editorial' ),
			'section'     => 'claudia_language',
			'type'        => 'text',
		)
	);
}
add_action( 'customize_register', 'claudia_customize_register' );

/**
 * Whether the built-in free Google translation switch is active.
 *
 * It is on when enabled in the Customizer and no plugin shortcode is set
 * (a shortcode takes precedence).
 *
 * @return bool
 */
function claudia_gtranslate_active() {
	if ( '' !== trim( (string) get_theme_mod( 'claudia_lang_shortcode', '' ) ) ) {
		return false;
	}
	return (bool) get_theme_mod( 'claudia_enable_gtranslate', true );
}

/**
 * Output the (hidden) Google Translate mount point in the footer.
 */
function claudia_gtranslate_mount() {
	if ( claudia_gtranslate_active() ) {
		echo '<div id="google_translate_element" aria-hidden="true" style="display:none"></div>';
	}
}
add_action( 'wp_footer', 'claudia_gtranslate_mount' );

/**
 * URL of the bundled portrait photo, with a cache-busting version based on the
 * file's modification time (so a replaced photo is reloaded, not served stale).
 *
 * @return string
 */
function claudia_portrait_url() {
	$path = get_template_directory() . '/assets/img/claudia.jpg';
	$uri  = get_template_directory_uri() . '/assets/img/claudia.jpg';
	$ver  = file_exists( $path ) ? filemtime( $path ) : wp_get_theme()->get( 'Version' );
	return $uri . '?v=' . $ver;
}

/**
 * Get the first <img> tag found in a post's content.
 *
 * @param int|WP_Post|null $post Optional post.
 * @return string The full <img …> tag, or empty string.
 */
function claudia_first_content_image_tag( $post = null ) {
	$post = get_post( $post );
	if ( ! $post ) {
		return '';
	}
	if ( preg_match( '/<img\b[^>]*>/i', $post->post_content, $m ) ) {
		return $m[0];
	}
	return '';
}

/**
 * Find the URL of the first image inside a post's content.
 *
 * @param int|WP_Post|null $post Optional post.
 * @return string Image URL or empty string.
 */
function claudia_first_content_image_url( $post = null ) {
	$tag = claudia_first_content_image_tag( $post );
	if ( $tag && preg_match( '/src=["\']([^"\']+)["\']/i', $tag, $m ) ) {
		return $m[1];
	}
	return '';
}

/**
 * Try to resolve the first content image to a media-library attachment ID,
 * so an optimized size (not the original) can be served.
 *
 * @param int|WP_Post|null $post Optional post.
 * @return int Attachment ID or 0.
 */
function claudia_first_content_image_id( $post = null ) {
	$tag = claudia_first_content_image_tag( $post );
	if ( ! $tag ) {
		return 0;
	}

	// 1) Editor images carry a wp-image-{ID} class — fastest and most reliable.
	if ( preg_match( '/wp-image-(\d+)/', $tag, $m ) ) {
		return (int) $m[1];
	}

	// 2) Fall back to resolving the image URL to an attachment.
	if ( preg_match( '/src=["\']([^"\']+)["\']/i', $tag, $s ) ) {
		$url = $s[1];
		$id  = attachment_url_to_postid( $url );
		if ( $id ) {
			return $id;
		}
		// The URL may point to a generated size (…-1024x768.jpg); try the original.
		$stripped = preg_replace( '/-\d+x\d+(\.[A-Za-z0-9]+)$/', '$1', $url );
		if ( $stripped !== $url ) {
			$id = attachment_url_to_postid( $stripped );
			if ( $id ) {
				return $id;
			}
		}
	}

	return 0;
}

/**
 * Whether a post has any usable image (featured image OR a content image).
 *
 * @param int|WP_Post|null $post Optional post.
 * @return bool
 */
function claudia_has_image( $post = null ) {
	return has_post_thumbnail( $post ) || '' !== claudia_first_content_image_url( $post );
}

/**
 * Output an <img> for a post: the featured image if set, otherwise the first
 * image found in the post content. Saves setting a featured image on every post.
 *
 * Prefers a media-library attachment so an optimized, responsive size is served
 * (with srcset) instead of a possibly full-size embedded original.
 *
 * @param string           $size Image size to request.
 * @param int|WP_Post|null $post Optional post.
 * @return string HTML <img> or empty string.
 */
function claudia_image( $size = 'large', $post = null ) {
	$post = get_post( $post );
	if ( has_post_thumbnail( $post ) ) {
		return get_the_post_thumbnail( $post, $size, array( 'alt' => the_title_attribute( array( 'echo' => false, 'post' => $post ) ) ) );
	}

	// Optimized: serve the requested registered size from the media library.
	$att_id = claudia_first_content_image_id( $post );
	if ( $att_id ) {
		$img = wp_get_attachment_image(
			$att_id,
			$size,
			false,
			array(
				'alt'     => get_the_title( $post ),
				'loading' => 'lazy',
			)
		);
		if ( $img ) {
			return $img;
		}
	}

	// Last resort: the raw embedded image (e.g. external or unresolved URL).
	$url = claudia_first_content_image_url( $post );
	if ( $url ) {
		return '<img src="' . esc_url( $url ) . '" alt="' . esc_attr( get_the_title( $post ) ) . '" loading="lazy">';
	}
	return '';
}

/**
 * Estimated reading time for a post (in minutes).
 *
 * @param int|null $post_id Optional post ID.
 * @return int
 */
function claudia_editorial_reading_time( $post_id = null ) {
	$content = get_post_field( 'post_content', $post_id );
	$words   = str_word_count( wp_strip_all_tags( $content ) );
	return max( 1, (int) ceil( $words / 200 ) );
}

/**
 * Output the primary category label for the current post.
 */
function claudia_editorial_primary_category() {
	$cats = get_the_category();
	if ( ! empty( $cats ) ) {
		echo '<a class="eyebrow" href="' . esc_url( get_category_link( $cats[0]->term_id ) ) . '">' . esc_html( $cats[0]->name ) . '</a>';
	}
}

/**
 * A compact "date · reading time" meta string.
 */
function claudia_editorial_meta() {
	printf(
		'<div class="meta"><time datetime="%1$s">%2$s</time><span class="meta__dot"></span><span>%3$s Min. Lesezeit</span></div>',
		esc_attr( get_the_date( DATE_W3C ) ),
		esc_html( get_the_date() ),
		esc_html( claudia_editorial_reading_time() )
	);
}
